from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import LeaveRequest
from .serializers import LeaveRequestSerializer
from .permissions import IsOwnerOrAdmin

class LeaveRequestViewSet(viewsets.ModelViewSet):
    serializer_class = LeaveRequestSerializer
    permission_classes = [IsAuthenticated, IsOwnerOrAdmin]

    def get_queryset(self):
        user = self.request.user
        # Admins see everything, interns see only their own
        if user.is_staff:
            return LeaveRequest.objects.all().order_by('-applied_on')
        return LeaveRequest.objects.filter(intern=user).order_by('-applied_on')

    def perform_create(self, serializer):
        serializer.save(intern=self.request.user)