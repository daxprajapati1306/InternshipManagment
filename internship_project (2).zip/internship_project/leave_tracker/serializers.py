from rest_framework import serializers
from .models import LeaveRequest

class LeaveRequestSerializer(serializers.ModelSerializer):
    intern_name = serializers.ReadOnlyField(source='intern.username')

    class Meta:
        model = LeaveRequest
        fields = ['id', 'intern', 'intern_name', 'start_date', 'end_date', 'reason', 'status', 'applied_on']
        read_only_fields = ['intern', 'status', 'applied_on']

    def validate(self, data):
        if data['start_date'] > data['end_date']:
            raise serializers.ValidationError("End date cannot be earlier than start date.")
        return data