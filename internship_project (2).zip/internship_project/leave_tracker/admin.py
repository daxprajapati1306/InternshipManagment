from django.contrib import admin
from .models import LeaveRequest

@admin.register(LeaveRequest)
class LeaveRequestAdmin(admin.ModelAdmin):
    # Creates columns in the data table
    list_display = ('intern', 'status', 'start_date', 'end_date', 'applied_on')
    # Adds a filter sidebar on the right
    list_filter = ('status', 'start_date')
    # Adds a search bar at the top
    search_fields = ('intern__username', 'reason')
    # Makes the status clickable to edit
    list_editable = ('status',)
    